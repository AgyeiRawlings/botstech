/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package cn.pedant.SweetAlert;

public final class R {
    private R() {
    }

    public static final class anim {
        public static int error_frame_in = 2130771996;
        public static int error_x_in = 2130771997;
        public static int modal_in = 2130771999;
        public static int modal_out = 2130772000;
        public static int success_bow_roate = 2130772008;
        public static int success_mask_layout = 2130772009;

        private anim() {
        }
    }

    public static final class attr {
        public static int customPivotX = 2130903361;
        public static int customPivotY = 2130903362;
        public static int fromDeg = 2130903516;
        public static int matProg_barColor = 2130903708;
        public static int matProg_barSpinCycleTime = 2130903709;
        public static int matProg_barWidth = 2130903710;
        public static int matProg_circleRadius = 2130903711;
        public static int matProg_fillRadius = 2130903712;
        public static int matProg_linearProgress = 2130903713;
        public static int matProg_progressIndeterminate = 2130903714;
        public static int matProg_rimColor = 2130903715;
        public static int matProg_rimWidth = 2130903716;
        public static int matProg_spinSpeed = 2130903717;
        public static int rollType = 2130903902;
        public static int sweet_alert_bg_drawable = 2130903996;
        public static int sweet_alert_content_text_color = 2130903997;
        public static int sweet_alert_title_text_color = 2130903998;
        public static int toDeg = 2130904135;

        private attr() {
        }
    }

    public static final class color {
        public static int blue_btn_bg_color = 2131034145;
        public static int blue_btn_bg_pressed_color = 2131034146;
        public static int button_text_color = 2131034159;
        public static int custom_float_bg = 2131034197;
        public static int error_stroke_color = 2131034242;
        public static int float_transparent = 2131034243;
        public static int gray_btn_bg_color = 2131034246;
        public static int gray_btn_bg_pressed_color = 2131034247;
        public static int main_blue_color = 2131034565;
        public static int main_blue_stroke_color = 2131034566;
        public static int main_cyan_color = 2131034567;
        public static int main_cyan_stroke_color = 2131034568;
        public static int main_disabled_color = 2131034569;
        public static int main_disabled_stroke_color = 2131034570;
        public static int main_green_color = 2131034571;
        public static int main_green_stroke_color = 2131034572;
        public static int main_orange_color = 2131034573;
        public static int main_orange_light_color = 2131034574;
        public static int main_orange_light_stroke_color = 2131034575;
        public static int main_orange_stroke_color = 2131034576;
        public static int material_blue_grey_80 = 2131034577;
        public static int material_blue_grey_90 = 2131034579;
        public static int material_blue_grey_95 = 2131034581;
        public static int material_deep_teal_20 = 2131034584;
        public static int material_deep_teal_50 = 2131034586;
        public static int message_color = 2131034682;
        public static int message_color_dark = 2131034683;
        public static int red_btn_bg_color = 2131034746;
        public static int red_btn_bg_pressed_color = 2131034747;
        public static int success_stroke_color = 2131034754;
        public static int sweet_dialog_bg_color = 2131034755;
        public static int sweet_dialog_bg_color_dark = 2131034756;
        public static int text_color = 2131034766;
        public static int title_color = 2131034767;
        public static int title_color_dark = 2131034768;
        public static int trans_success_stroke_color = 2131034771;
        public static int warning_stroke_color = 2131034772;

        private color() {
        }
    }

    public static final class dimen {
        public static int alert_width = 2131099730;
        public static int buttons_stroke_width = 2131099734;
        public static int common_circle_width = 2131099739;
        public static int custom_image_size = 2131099747;
        public static int progress_circle_radius = 2131100217;

        private dimen() {
        }
    }

    public static final class drawable {
        public static int blue_button_background = 2131165275;
        public static int dialog_background = 2131165308;
        public static int dialog_background_dark = 2131165309;
        public static int error_center_x = 2131165311;
        public static int error_circle = 2131165312;
        public static int gray_button_background = 2131165318;
        public static int green_button_background = 2131165319;
        public static int red_button_background = 2131165378;
        public static int success_bow = 2131165379;
        public static int success_circle = 2131165380;
        public static int warning_circle = 2131165405;
        public static int warning_sigh = 2131165406;

        private drawable() {
        }
    }

    public static final class id {
        public static int buttons_container = 2131230831;
        public static int cancel_button = 2131230834;
        public static int confirm_button = 2131230858;
        public static int content_text = 2131230863;
        public static int custom_image = 2131230872;
        public static int custom_view_container = 2131230873;
        public static int error_frame = 2131230916;
        public static int error_x = 2131230917;
        public static int loading = 2131230976;
        public static int mask_left = 2131230979;
        public static int mask_right = 2131230980;
        public static int neutral_button = 2131231047;
        public static int progressWheel = 2131231081;
        public static int progress_dialog = 2131231083;
        public static int success_frame = 2131231159;
        public static int success_tick = 2131231160;
        public static int title_text = 2131231202;
        public static int warning_frame = 2131231306;
        public static int x = 2131231314;
        public static int y = 2131231317;
        public static int z = 2131231318;

        private id() {
        }
    }

    public static final class layout {
        public static int alert_dialog = 2131427367;

        private layout() {
        }
    }

    public static final class string {
        public static int LOADING = 2131623936;
        public static int app_name = 2131623966;
        public static int default_progressbar = 2131623995;
        public static int dialog_cancel = 2131623996;
        public static int dialog_default_title = 2131623997;
        public static int dialog_ok = 2131623998;

        private string() {
        }
    }

    public static final class style {
        public static int alert_dialog_dark = 2131690493;
        public static int alert_dialog_light = 2131690494;
        public static int dialog_blue_button = 2131690495;

        private style() {
        }
    }

    public static final class styleable {
        public static int[] ProgressWheel = new int[]{2130903708, 2130903709, 2130903710, 2130903711, 2130903712, 2130903713, 2130903714, 2130903715, 2130903716, 2130903717};
        public static int ProgressWheel_matProg_barColor = 0;
        public static int ProgressWheel_matProg_barSpinCycleTime = 1;
        public static int ProgressWheel_matProg_barWidth = 2;
        public static int ProgressWheel_matProg_circleRadius = 3;
        public static int ProgressWheel_matProg_fillRadius = 4;
        public static int ProgressWheel_matProg_linearProgress = 5;
        public static int ProgressWheel_matProg_progressIndeterminate = 6;
        public static int ProgressWheel_matProg_rimColor = 7;
        public static int ProgressWheel_matProg_rimWidth = 8;
        public static int ProgressWheel_matProg_spinSpeed = 9;
        public static int[] Rotate3dAnimation = new int[]{2130903361, 2130903362, 2130903516, 2130903902, 2130904135};
        public static int Rotate3dAnimation_customPivotX = 0;
        public static int Rotate3dAnimation_customPivotY = 1;
        public static int Rotate3dAnimation_fromDeg = 2;
        public static int Rotate3dAnimation_rollType = 3;
        public static int Rotate3dAnimation_toDeg = 4;

        private styleable() {
        }
    }

}

